# Solution Package for Deployment

## Full Name
Jarrett Ellis

## Overview
This repository contains a solution package that is intended to be built and deployed using a set Makefile. 

The solution consists of a shell script, additional required assets, and accompanying documentation. The process involves zipping the contents into a package and committing it to a Git repository.

## Files and Directories
- **solution.sh**: This is the main shell script of your solution.
- **assets/**: This directory contains additional required assets for the solution.
- **README.md**: This document provides the necessary description and instructions related to the solution package.

## Makefile Targets
Several actions can be performed via the Makefile:

### Help
Displays helpful instructions about the available Makefile commands.
```bash
make help
